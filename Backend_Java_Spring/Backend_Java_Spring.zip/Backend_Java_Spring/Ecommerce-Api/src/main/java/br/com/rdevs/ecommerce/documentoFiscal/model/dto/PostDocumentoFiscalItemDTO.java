package br.com.rdevs.ecommerce.documentoFiscal.model.dto;

import lombok.Data;

import java.math.BigInteger;

@Data
public class PostDocumentoFiscalItemDTO {


    private Integer qtProduto;

    private BigInteger cdProduto;



}
