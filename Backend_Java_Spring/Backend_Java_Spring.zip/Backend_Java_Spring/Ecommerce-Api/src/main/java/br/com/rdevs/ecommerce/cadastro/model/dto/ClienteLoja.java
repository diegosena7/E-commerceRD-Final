package br.com.rdevs.ecommerce.cadastro.model.dto;

import lombok.Data;

@Data
public class ClienteLoja {

    private String nrCpf;
    private String nmEmail;

}
