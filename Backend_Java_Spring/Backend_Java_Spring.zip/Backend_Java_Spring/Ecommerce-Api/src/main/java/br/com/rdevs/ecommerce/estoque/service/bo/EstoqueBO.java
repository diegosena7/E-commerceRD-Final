package br.com.rdevs.ecommerce.estoque.service.bo;

import org.springframework.stereotype.Component;

@Component
public class EstoqueBO {

}
