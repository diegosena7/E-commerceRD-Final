package br.com.rdevs.ecommerce.cadastro.model.dto;

import lombok.Data;

@Data
public class Login {
    private String login;
    private String senha;

}
